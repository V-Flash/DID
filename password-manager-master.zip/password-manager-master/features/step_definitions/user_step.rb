Given(/^I am an unauthorised user$/) do
	visit '/logout'
end