Password Manager (WIP)
======================

A simple password manager project built in Ruby Sinatra.

  - It has a simple user authentication system
  - Multiple user support
  - Full CRUD for passwords

To run the app run `shotgun config.ru` from the command line

***Disclaimer:***
*This should not actually be used for real.*
