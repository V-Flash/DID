Get the latest version of The Lobster Font at
http://www.impallari.com/lobster

And please donate if you liked it!

Thanks
Pablo Impallari



